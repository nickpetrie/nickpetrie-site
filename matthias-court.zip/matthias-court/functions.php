<?php
/**
 * Matthias Court theme.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MC_THEME_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );

/**
 * Theme supports and editor styles.
 */
function mc_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
	load_theme_textdomain( 'matthias-court', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'mc_setup' );

/**
 * Front-end stylesheet for the theme's own components.
 */
function mc_enqueue_styles() {
	$path = '/assets/css/theme.css';
	wp_enqueue_style( 'matthias-court', get_theme_file_uri( $path ), array(), (string) filemtime( get_theme_file_path( $path ) ) );
	// Front end only: anything below the footer (or an overscroll bounce) shows the footer's green, not a pale strip.
	// Anything a host or plugin appends after the footer (such as a credit line) is painted to match it.
	wp_add_inline_style( 'matthias-court', 'html,body{background-color:#1F3328!important}.wp-site-blocks{background-color:#F4F5F1}.mc-part-footer{margin-bottom:0!important}.mc-part-footer~*{margin:0!important;background-color:#1F3328!important;color:#B9C6BC!important}.mc-part-footer~* a{color:#F4F5F1!important}' );
}
add_action( 'wp_enqueue_scripts', 'mc_enqueue_styles' );

require_once get_theme_file_path( '/inc/richmond-paths.php' );
require_once get_theme_file_path( '/inc/notices.php' );
require_once get_theme_file_path( '/inc/guide.php' );
require_once get_theme_file_path( '/inc/leaseholders.php' );
require_once get_theme_file_path( '/inc/blocks.php' );
