/**
 * Editor side of the theme's server-rendered blocks: a live preview,
 * plus simple settings fields in the block sidebar. No build step.
 */
( function ( wp ) {
	'use strict';
	const el = wp.element.createElement;
	const { registerBlockType } = wp.blocks;
	const { InspectorControls, useBlockProps } = wp.blockEditor;
	const { PanelBody, TextControl, ToggleControl, RangeControl, SelectControl, Disabled } = wp.components;
	const ServerSideRender = wp.serverSideRender;
	const __ = wp.i18n.__;

	// [ attribute, label, kind, options ] per block. Kinds: text, url, number, toggle, date, time, select.
	const fields = {
		'matthias-court/paths': [],
		'matthias-court/brand': [],
		'matthias-court/notice-meta': [
			[ 'postedLabel', __( 'Word before the posted date', 'matthias-court' ), 'text' ],
			[ 'updatedLabel', __( 'Word before the updated date', 'matthias-court' ), 'text' ],
			[ 'untilLabel', __( 'Word before the end date', 'matthias-court' ), 'text' ],
			[ 'endedLabel', __( 'Word once it has ended', 'matthias-court' ), 'text' ],
		],
		'matthias-court/agm': [
			[ 'date', __( 'Date of the next AGM', 'matthias-court' ), 'date' ],
			[ 'time', __( 'Start time', 'matthias-court' ), 'time' ],
			[ 'mode', __( 'Where is it?', 'matthias-court' ), 'select', [ { value: 'in-person', label: __( 'In person', 'matthias-court' ) }, { value: 'online', label: __( 'Online', 'matthias-court' ) } ] ],
			[ 'location', __( 'In person: where (shown as written)', 'matthias-court' ), 'text' ],
			[ 'onlineText', __( 'Online: how (shown as written)', 'matthias-court' ), 'text' ],
			[ 'link', __( 'Online: Teams meeting link', 'matthias-court' ), 'url' ],
			[ 'note', __( 'Note after the place', 'matthias-court' ), 'text' ],
			[ 'label', __( 'Label before the date', 'matthias-court' ), 'text' ],
			[ 'calendarLabel', __( 'Calendar link text (in person)', 'matthias-court' ), 'text' ],
			[ 'joinLabel', __( 'Join link text (online)', 'matthias-court' ), 'text' ],
		],
		'matthias-court/latest-documents': [
			[ 'source', __( 'Documents page address (slug)', 'matthias-court' ), 'text' ],
			[ 'count', __( 'How many to show', 'matthias-court' ), 'number' ],
			[ 'buttonLabel', __( 'Button text', 'matthias-court' ), 'text' ],
			[ 'note', __( 'Note under the button', 'matthias-court' ), 'text' ],
			[ 'emptyText', __( 'Text when there are no documents', 'matthias-court' ), 'text' ],
		],
		'matthias-court/emergency': [
			[ 'title', __( 'Heading', 'matthias-court' ), 'text' ],
			[ 'fireLabel', __( 'First label', 'matthias-court' ), 'text' ],
			[ 'gasLabel', __( 'Second label', 'matthias-court' ), 'text' ],
			[ 'outOfHoursLabel', __( 'Third label', 'matthias-court' ), 'text' ],
			[ 'fire', __( 'Fire', 'matthias-court' ), 'text' ],
			[ 'gas', __( 'Smell gas', 'matthias-court' ), 'text' ],
			[ 'outOfHours', __( 'Urgent building problem out of hours', 'matthias-court' ), 'text' ],
		],
		'matthias-court/routes': [
			[ 'heading', __( 'Heading', 'matthias-court' ), 'text' ],
			[ 'reportTitle', __( 'First route: title', 'matthias-court' ), 'text' ],
			[ 'reportText', __( 'First route: description', 'matthias-court' ), 'text' ],
			[ 'reportUrl', __( 'First route: link', 'matthias-court' ), 'url' ],
			[ 'guideTitle', __( 'Second route: title', 'matthias-court' ), 'text' ],
			[ 'guideText', __( 'Second route: description', 'matthias-court' ), 'text' ],
			[ 'guideUrl', __( 'Second route: link', 'matthias-court' ), 'url' ],
			[ 'contactTitle', __( 'Third route: title', 'matthias-court' ), 'text' ],
			[ 'contactText', __( 'Third route: description', 'matthias-court' ), 'text' ],
			[ 'contactUrl', __( 'Third route: link', 'matthias-court' ), 'url' ],
		],
		'matthias-court/notices': [
			[ 'count', __( 'How many notices to show', 'matthias-court' ), 'number' ],
			[ 'showEnded', __( 'Also list past notices', 'matthias-court' ), 'toggle' ],
			[ 'emptyText', __( 'Text when there are no notices', 'matthias-court' ), 'text' ],
			[ 'pastHeading', __( 'Heading above past notices', 'matthias-court' ), 'text' ],
		],
		'matthias-court/guide-index': [
			[ 'parentSlug', __( 'Parent page address (leave empty for this page)', 'matthias-court' ), 'text' ],
			[ 'moreLabel', __( 'Heading for pages with no group', 'matthias-court' ), 'text' ],
		],
		'matthias-court/guide-nav': [
			[ 'parentSlug', __( 'Parent page address (leave empty for this section)', 'matthias-court' ), 'text' ],
			[ 'moreLabel', __( 'Heading for pages with no group', 'matthias-court' ), 'text' ],
		],
	};

	function control( spec, attributes, setAttributes ) {
		const [ key, label, kind, options ] = spec;
		const set = ( value ) => setAttributes( { [ key ]: value } );
		if ( 'toggle' === kind ) {
			return el( ToggleControl, { key, label, checked: !! attributes[ key ], onChange: set, __nextHasNoMarginBottom: true } );
		}
		if ( 'number' === kind ) {
			return el( RangeControl, { key, label, value: attributes[ key ], onChange: set, min: 1, max: 20, __nextHasNoMarginBottom: true } );
		}
		if ( 'select' === kind ) {
			return el( SelectControl, { key, label, value: attributes[ key ], options, onChange: set, __nextHasNoMarginBottom: true } );
		}
		return el( TextControl, { key, label, type: [ 'url', 'date', 'time' ].includes( kind ) ? kind : 'text', value: attributes[ key ] || '', onChange: set, __nextHasNoMarginBottom: true } );
	}

	Object.keys( fields ).forEach( ( name ) => {
		registerBlockType( name, {
			edit( props ) {
				const blockProps = useBlockProps();
				const specs = fields[ name ];
				return el(
					'div',
					blockProps,
					specs.length
						? el(
							InspectorControls,
							null,
							el( PanelBody, { title: __( 'Settings', 'matthias-court' ) }, specs.map( ( spec ) => control( spec, props.attributes, props.setAttributes ) ) )
						)
						: null,
					el( Disabled, null, el( ServerSideRender, { block: name, attributes: props.attributes, urlQueryArgs: props.context && props.context.postId ? { post_id: props.context.postId } : {} } ) )
				);
			},
			save: () => null,
		} );
	} );
} )( window.wp );
