/**
 * "Notice settings" panel in the post editor: status and end date.
 */
( function ( wp ) {
	'use strict';
	const el = wp.element.createElement;
	const { registerPlugin } = wp.plugins;
	const PluginDocumentSettingPanel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || ( wp.editPost && wp.editPost.PluginDocumentSettingPanel );
	const { SelectControl, TextControl } = wp.components;
	const { useSelect, useDispatch } = wp.data;
	const __ = wp.i18n.__;

	if ( ! PluginDocumentSettingPanel ) {
		return;
	}

	function NoticePanel() {
		const postType = useSelect( ( select ) => select( 'core/editor' ).getCurrentPostType(), [] );
		const meta = useSelect( ( select ) => select( 'core/editor' ).getEditedPostAttribute( 'meta' ) || {}, [] );
		const { editPost } = useDispatch( 'core/editor' );
		if ( 'post' !== postType ) {
			return null;
		}
		const setMeta = ( key, value ) => editPost( { meta: { ...meta, [ key ]: value } } );
		const options = [ { value: '', label: __( 'No status', 'matthias-court' ) } ].concat( window.mcNoticeStatuses || [] );
		return el(
			PluginDocumentSettingPanel,
			{ name: 'mc-notice-settings', title: __( 'Notice settings', 'matthias-court' ), initialOpen: true },
			el( SelectControl, {
				label: __( 'Status', 'matthias-court' ),
				value: meta.mc_status || '',
				options,
				onChange: ( value ) => setMeta( 'mc_status', value ),
				__nextHasNoMarginBottom: true,
			} ),
			el( 'div', { style: { height: '16px' } } ),
			el( TextControl, {
				label: __( 'Take down after', 'matthias-court' ),
				help: __( 'Leave empty to keep it up. After this date it moves to Past notices.', 'matthias-court' ),
				type: 'date',
				value: meta.mc_end_date || '',
				onChange: ( value ) => setMeta( 'mc_end_date', value ),
				__nextHasNoMarginBottom: true,
			} )
		);
	}

	registerPlugin( 'mc-notice-settings', { render: NoticePanel } );
} )( window.wp );
