/* Document library: search, category filter, sort, and a preview pane. Works without it too:
   every Preview link simply opens the PDF in a new tab. */
( () => {
	'use strict';
	// Phones and tablets show PDFs poorly inside a page, so there Preview opens the PDF itself.
	const inlinePreview = () => window.matchMedia( '(min-width: 760px)' ).matches && ! /iPhone|iPad|iPod|Android/i.test( navigator.userAgent );

	function init( root ) {
		const rows = Array.from( root.querySelectorAll( 'tbody tr' ) );
		if ( ! rows.length ) return;
		const tbody = root.querySelector( 'tbody' );
		const search = root.querySelector( '[data-doclib-search]' );
		const chips = Array.from( root.querySelectorAll( '[data-doclib-cat]' ) );
		const count = root.querySelector( '[data-doclib-count]' );
		const none = root.querySelector( '[data-doclib-none]' );
		const pane = root.querySelector( '[data-doclib-pane]' );
		const frame = root.querySelector( '[data-doclib-frame]' );
		let cat = '';
		let sort = { key: 'date', dir: -1 };

		function apply() {
			const words = ( search.value || '' ).toLowerCase().split( /\s+/ ).filter( Boolean );
			let shown = 0;
			rows.forEach( ( row ) => {
				const ok = ( ! cat || row.dataset.cat === cat ) && words.every( ( w ) => row.dataset.text.includes( w ) );
				row.hidden = ! ok;
				if ( ok ) shown++;
			} );
			count.textContent = shown === rows.length ? `${ rows.length } document${ rows.length === 1 ? '' : 's' }` : `${ shown } of ${ rows.length } documents`;
			none.hidden = shown > 0;
		}

		function order() {
			const sorted = rows.slice().sort( ( a, b ) => {
				if ( sort.key === 'title' ) return sort.dir * a.dataset.title.localeCompare( b.dataset.title, undefined, { numeric: true } );
				return sort.dir * ( Number( a.dataset.date ) - Number( b.dataset.date ) );
			} );
			sorted.forEach( ( r ) => tbody.appendChild( r ) );
			root.querySelectorAll( 'th' ).forEach( ( th ) => th.removeAttribute( 'aria-sort' ) );
			const th = root.querySelector( `[data-doclib-sort="${ sort.key }"]` ).closest( 'th' );
			th.setAttribute( 'aria-sort', sort.dir === 1 ? 'ascending' : 'descending' );
		}

		search.addEventListener( 'input', apply );
		chips.forEach( ( chip ) => chip.addEventListener( 'click', () => {
			cat = chip.dataset.doclibCat;
			chips.forEach( ( c ) => c.setAttribute( 'aria-pressed', String( c === chip ) ) );
			apply();
		} ) );
		root.querySelectorAll( '[data-doclib-sort]' ).forEach( ( btn ) => btn.addEventListener( 'click', () => {
			const key = btn.dataset.doclibSort;
			sort = sort.key === key ? { key, dir: -sort.dir } : { key, dir: key === 'date' ? -1 : 1 };
			order();
		} ) );

		root.addEventListener( 'click', ( e ) => {
			const link = e.target.closest( '[data-doclib-preview]' );
			if ( ! link || ! pane || typeof pane.showModal !== 'function' || ! inlinePreview() ) return;
			e.preventDefault();
			const row = link.closest( 'tr' );
			pane.querySelector( '[data-doclib-pane-title]' ).textContent = row.dataset.title;
			pane.querySelector( '[data-doclib-pane-meta]' ).textContent = [ row.dataset.cat, row.querySelector( 'time' ) ? row.querySelector( 'time' ).textContent : '', link.dataset.doclibMeta ].filter( Boolean ).join( ' · ' );
			pane.querySelector( '[data-doclib-pane-download]' ).href = link.href;
			pane.querySelector( '[data-doclib-pane-open]' ).href = link.href;
			frame.src = link.href + '#view=FitH';
			pane.showModal();
		} );
		if ( pane ) {
			pane.querySelector( '[data-doclib-close]' ).addEventListener( 'click', () => pane.close() );
			pane.addEventListener( 'click', ( e ) => { if ( e.target === pane ) pane.close(); } );
			pane.addEventListener( 'close', () => { frame.src = 'about:blank'; } );
		}
		apply();
	}

	const boot = () => document.querySelectorAll( '.mc-doclib' ).forEach( init );
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', boot, { once: true } );
	else boot();
} )();
