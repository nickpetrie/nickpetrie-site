/* No libraries or globals. Routes are fitted to the page layout on load and resize, so the
   visitors keep to open ground on every screen. Nothing runs per frame. */
(() => {
  'use strict';
  const rand = (a, b) => a + Math.random() * (b - a);
  const r1 = n => Math.round(n * 10) / 10;

  function init(root) {
    if (root.dataset.initialized) return;
    const art = root.querySelector('.mcrp-art');
    const button = root.querySelector('.mcrp-toggle');
    if (!art || !button) return;
    root.dataset.initialized = 'true';
    const hero = root.closest('.mc-richmond-hero') || root.parentElement;
    const ground = art.querySelector('.mcrp-ground');
    const actor = n => art.querySelector('.mcrp-' + n);
    const cyclist = actor('cyclist'), plane = actor('plane'), deer = actor('deer'), dog = actor('dogwalk');
    const deerFlip = deer && deer.querySelector('.mcrp-flip');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const supported = window.CSS && CSS.supports('offset-path', 'path("M0 0 L1 1")');
    let userPaused = false;
    let inView = true;
    let geo = null;

    function sync() {
      root.dataset.reduced = String(reduced.matches);
      root.dataset.paused = String(userPaused || reduced.matches || !inView || document.hidden || !supported);
      button.hidden = reduced.matches || !supported;
      button.setAttribute('aria-pressed', String(userPaused));
      button.setAttribute('aria-label', userPaused ? button.dataset.resumeLabel : button.dataset.pauseLabel);
    }

    function wander() {
      if (!geo || !deer) return;
      // A short, random stroll somewhere along the open ground, in either direction.
      const pad = 60 * geo.k;
      const lo = geo.left + pad, hi = geo.right - pad;
      const dist = rand(110, 230) * geo.k;
      let sx = rand(lo, hi);
      let dir = Math.random() < 0.5 ? -1 : 1;
      if (sx + dir * dist > hi || sx + dir * dist < lo) dir = -dir;
      const ex = Math.max(lo, Math.min(hi, sx + dir * dist));
      const y = geo.gy - 3 * geo.k;
      deer.style.offsetPath = `path('M${r1(sx)} ${r1(y)} Q${r1((sx + ex) / 2)} ${r1(y + rand(-5, 5) * geo.k)} ${r1(ex)} ${r1(y)}')`;
      if (deerFlip) deerFlip.dataset.dir = ex < sx ? '-1' : '1';
      size();
    }

    // Keep the visitors the same size on screen whatever the screen width, about as they look on a laptop.
    function size() {
      const f = geo ? Math.max(0.6, Math.min(1.1, 1.14 * geo.k)) : 1;
      art.querySelectorAll('.mcrp-flip').forEach(g => {
        const sx = parseFloat(g.dataset.sx) * f * (g.dataset.dir === '-1' ? -1 : 1), sy = parseFloat(g.dataset.sy) * f;
        g.setAttribute('transform', `scale(${r1(sx * 100) / 100} ${r1(sy * 100) / 100})` + (g.dataset.extra || ''));
      });
    }

    function layout() {
      art.setAttribute('viewBox', root.clientWidth < 540 ? '540 0 660 700' : '0 0 1200 700');
      const ctm = art.getScreenCTM();
      if (!ctm || !ground) return;
      const inv = ctm.inverse();
      const pt = (x, y) => { const p = art.createSVGPoint(); p.x = x; p.y = y; return p.matrixTransform(inv); };
      const box = s => { const e = hero.querySelector(s); return e ? e.getBoundingClientRect() : null; };
      const h = hero.getBoundingClientRect();
      const header = box('.mc-header'), title = box('.mc-hero__title');
      const text = box('.mc-search') || box('.mc-hero__text'), panel = box('.mc-routes');
      // Stacked layout (phones, tablets): the ground runs through the gap between the search and the panel,
      // so it is on screen straight away. Side by side: it runs along the foot of the hero, above the pause button.
      const stacked = text && panel && panel.top >= text.bottom - 1;
      const groundPx = stacked ? (text.bottom + panel.top) / 2 + 22 : h.bottom - 58;
      const skyPx = header && title ? (header.bottom + title.top) / 2 : h.top + h.height * 0.18;
      const k = pt(0, 1).y - pt(0, 0).y; // SVG units per CSS pixel
      const left = pt(h.left, 0).x, right = pt(h.right, 0).x;
      const L = left - 90 * k, R = right + 90 * k, W = R - L;
      const gy = pt(0, groundPx).y, sy = pt(0, skyPx).y;
      const d = `M${r1(L)} ${r1(gy)} C${r1(L + W * 0.3)} ${r1(gy - 7 * k)} ${r1(L + W * 0.6)} ${r1(gy + 6 * k)} ${r1(R)} ${r1(gy - 3 * k)}`;
      const back = `M${r1(R)} ${r1(gy - 3 * k)} C${r1(L + W * 0.6)} ${r1(gy + 6 * k)} ${r1(L + W * 0.3)} ${r1(gy - 7 * k)} ${r1(L)} ${r1(gy)}`;
      ground.setAttribute('d', d);
      if (cyclist) cyclist.style.offsetPath = `path('${d}')`;
      if (dog) dog.style.offsetPath = `path('${back}')`;
      if (plane) {
        plane.style.offsetPath = `path('M${r1(R)} ${r1(sy - 7 * k)} L${r1(L)} ${r1(sy + 7 * k)}')`;
        // Only fly where there is open sky between the header and the title.
        plane.style.display = header && title && title.top - header.bottom < 34 ? 'none' : '';
      }
      geo = { k, left, right, gy };
      wander();
      size();
    }

    button.addEventListener('click', () => { userPaused = !userPaused; sync(); });
    if (reduced.addEventListener) reduced.addEventListener('change', sync);
    else reduced.addListener(sync);
    document.addEventListener('visibilitychange', sync);
    if (deer) deer.addEventListener('animationiteration', e => { if (e.target === deer) wander(); });
    if ('ResizeObserver' in window) new ResizeObserver(layout).observe(hero);
    else window.addEventListener('resize', layout);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);
    window.addEventListener('load', layout, { once: true });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => { inView = entries[0].isIntersecting; sync(); }).observe(root);
    }
    layout();
    sync();
    root.dataset.ready = 'true';
  }
  function boot() { document.querySelectorAll('.mc-richmond-paths').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
