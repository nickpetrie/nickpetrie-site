/* No libraries, globals or per-frame JavaScript. Safe for multiple instances. */
(() => {
  'use strict';
  function init(root) {
    if (root.dataset.initialized) return;
    const art = root.querySelector('.mcrp-art');
    const button = root.querySelector('.mcrp-toggle');
    if (!art || !button) return;
    root.dataset.initialized = 'true';
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const supported = window.CSS && CSS.supports('offset-path', 'path("M0 0 L1 1")');
    let userPaused = false;
    let inView = true;
    function sync() {
      root.dataset.reduced = String(reduced.matches);
      root.dataset.paused = String(userPaused || reduced.matches || !inView || document.hidden || !supported);
      button.hidden = reduced.matches || !supported;
      button.setAttribute('aria-pressed', String(userPaused));
      button.textContent = userPaused ? button.dataset.resumeLabel : button.dataset.pauseLabel;
    }
    function resize() {
      art.setAttribute('viewBox', root.clientWidth < 540 ? '540 0 660 700' : '0 0 1200 700');
    }
    button.addEventListener('click', () => { userPaused = !userPaused; sync(); });
    if (reduced.addEventListener) reduced.addEventListener('change', sync);
    else reduced.addListener(sync);
    document.addEventListener('visibilitychange', sync);
    if ('ResizeObserver' in window) new ResizeObserver(resize).observe(root);
    else window.addEventListener('resize', resize);
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => { inView = entries[0].isIntersecting; sync(); }).observe(root);
    }
    resize();
    sync();
    root.dataset.ready = 'true';
  }
  function boot() { document.querySelectorAll('.mc-richmond-paths').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true});
  else boot();
})();
