<?php
/**
 * Guide contents: every guide page, in its group.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_post   = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : 0;
$mc_groups = mc_guide_groups( $attributes['parentSlug'], $mc_post, $attributes['moreLabel'] );
if ( ! $mc_groups ) {
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		echo '<p>' . esc_html__( 'Publish pages under this page and they will be listed here, in their guide groups.', 'matthias-court' ) . '</p>';
	}
	return;
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-guide-index' ) ); ?>>
	<?php foreach ( $mc_groups as $mc_group ) : ?>
		<div class="mc-guide-index__group">
			<h3 class="mc-guide-index__heading"><?php echo esc_html( $mc_group['name'] ); ?></h3>
			<ul>
				<?php foreach ( $mc_group['pages'] as $mc_page ) : ?>
					<li><a href="<?php echo esc_url( get_permalink( $mc_page ) ); ?>"><span><?php echo esc_html( get_the_title( $mc_page ) ); ?></span><?php echo mc_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endforeach; ?>
</div>
