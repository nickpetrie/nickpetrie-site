<?php
/**
 * Document library: every file on this page in one table, newest first, with search,
 * a category filter, and preview and download for each. Categories are the headings
 * the files sit under; titles are the File blocks' link text.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_post = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : get_the_ID();
$mc_docs = $mc_post ? mc_documents_on_page( $mc_post ) : array();
$mc_by_order = $mc_docs;
usort( $mc_by_order, function ( $a, $b ) { return $a['order'] - $b['order']; } );
// Category buttons follow the order of the headings on the page.
$mc_cats = array_values( array_unique( array_filter( wp_list_pluck( $mc_by_order, 'group' ) ) ) );

$mc_path = '/assets/js/doclib.js';
wp_enqueue_script( 'mc-doclib', get_theme_file_uri( $mc_path ), array(), (string) filemtime( get_theme_file_path( $mc_path ) ), true );

$mc_uid = 'mc-doclib-' . wp_unique_id();
$mc_ico = array(
	'eye'  => '<svg aria-hidden="true" focusable="false" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
	'down' => '<svg aria-hidden="true" focusable="false" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"></path><path d="M7 10l5 5 5-5"></path><path d="M5 20h14"></path></svg>',
	'x'    => '<svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"></path></svg>',
);
$mc_size = function ( $bytes ) {
	return $bytes ? size_format( $bytes, $bytes < 1048576 ? 0 : 1 ) : '';
};
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-doclib', 'id' => $mc_uid ) ); ?>>
	<?php if ( ! $mc_docs ) : ?>
		<p class="mc-doclib__empty"><?php echo esc_html( $attributes['emptyText'] ); ?></p>
	<?php else : ?>
		<div class="mc-doclib__tools">
			<label class="mc-doclib__search">
				<span class="screen-reader-text"><?php echo esc_html( $attributes['searchLabel'] ); ?></span>
				<input type="search" placeholder="<?php echo esc_attr( $attributes['searchLabel'] ); ?>" autocomplete="off" data-doclib-search>
			</label>
			<div class="mc-doclib__filters" role="group" aria-label="<?php esc_attr_e( 'Filter by category', 'matthias-court' ); ?>">
				<button type="button" class="mc-doclib__chip" aria-pressed="true" data-doclib-cat=""><?php echo esc_html( $attributes['allLabel'] ); ?></button>
				<?php foreach ( $mc_cats as $mc_cat ) : ?>
					<button type="button" class="mc-doclib__chip" aria-pressed="false" data-doclib-cat="<?php echo esc_attr( $mc_cat ); ?>"><?php echo esc_html( $mc_cat ); ?></button>
				<?php endforeach; ?>
			</div>
		</div>
		<p class="mc-doclib__count" aria-live="polite" data-doclib-count></p>
		<table class="mc-doclib__table">
			<thead>
				<tr>
					<th scope="col"><button type="button" class="mc-doclib__sort" data-doclib-sort="title"><?php esc_html_e( 'Document', 'matthias-court' ); ?></button></th>
					<th scope="col" class="mc-doclib__col-cat"><?php esc_html_e( 'Category', 'matthias-court' ); ?></th>
					<th scope="col" class="mc-doclib__col-date" aria-sort="descending"><button type="button" class="mc-doclib__sort" data-doclib-sort="date"><?php esc_html_e( 'Date', 'matthias-court' ); ?></button></th>
					<th scope="col" class="mc-doclib__col-actions"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'matthias-court' ); ?></span></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $mc_docs as $mc_doc ) : ?>
					<?php
					$mc_is_pdf = 'pdf' === $mc_doc['type'];
					$mc_meta   = trim( strtoupper( $mc_doc['type'] ) . ( $mc_doc['size'] ? ', ' . $mc_size( $mc_doc['size'] ) : '' ), ', ' );
					?>
					<tr data-title="<?php echo esc_attr( $mc_doc['title'] ); ?>" data-cat="<?php echo esc_attr( $mc_doc['group'] ); ?>" data-date="<?php echo esc_attr( (string) $mc_doc['date'] ); ?>" data-text="<?php echo esc_attr( strtolower( $mc_doc['title'] . ' ' . $mc_doc['group'] . ' ' . $mc_doc['desc'] ) ); ?>">
						<td class="mc-doclib__doc">
							<span class="mc-doclib__title"><?php echo esc_html( $mc_doc['title'] ); ?></span>
							<?php if ( $mc_doc['desc'] ) : ?><span class="mc-doclib__desc"><?php echo esc_html( $mc_doc['desc'] ); ?></span><?php endif; ?>
							<span class="mc-doclib__small"><?php echo esc_html( implode( ' · ', array_filter( array( $mc_doc['group'], $mc_doc['date'] ? wp_date( 'j M Y', $mc_doc['date'] ) : '' ) ) ) ); ?></span>
						</td>
						<td class="mc-doclib__col-cat"><?php echo esc_html( $mc_doc['group'] ); ?></td>
						<td class="mc-doclib__col-date"><?php echo $mc_doc['date'] ? '<time datetime="' . esc_attr( wp_date( 'Y-m-d', $mc_doc['date'] ) ) . '">' . esc_html( wp_date( 'j M Y', $mc_doc['date'] ) ) . '</time>' : ''; ?></td>
						<td class="mc-doclib__col-actions">
							<?php if ( $mc_is_pdf && $mc_doc['url'] ) : ?>
								<a class="mc-doclib__btn" href="<?php echo esc_url( $mc_doc['url'] ); ?>" target="_blank" rel="noopener" data-doclib-preview data-doclib-meta="<?php echo esc_attr( $mc_meta ); ?>"><?php echo $mc_ico['eye']; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?><span><?php esc_html_e( 'Preview', 'matthias-court' ); ?></span></a>
							<?php endif; ?>
							<?php if ( $mc_doc['url'] ) : ?>
								<a class="mc-doclib__btn mc-doclib__btn--quiet" href="<?php echo esc_url( $mc_doc['url'] ); ?>" download><?php echo $mc_ico['down']; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?><span><?php esc_html_e( 'Download', 'matthias-court' ); ?></span><?php if ( $mc_meta ) : ?><span class="mc-doclib__meta"><?php echo esc_html( $mc_meta ); ?></span><?php endif; ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="mc-doclib__none" hidden data-doclib-none><?php esc_html_e( 'No documents match. Try another word, or show all categories.', 'matthias-court' ); ?></p>

		<dialog class="mc-doclib__pane" aria-labelledby="<?php echo esc_attr( $mc_uid ); ?>-title" data-doclib-pane>
			<div class="mc-doclib__pane-head">
				<div>
					<h2 class="mc-doclib__pane-title" id="<?php echo esc_attr( $mc_uid ); ?>-title" data-doclib-pane-title></h2>
					<p class="mc-doclib__pane-meta" data-doclib-pane-meta></p>
				</div>
				<div class="mc-doclib__pane-actions">
					<a class="mc-doclib__btn" href="#" download data-doclib-pane-download><?php echo $mc_ico['down']; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?><span><?php esc_html_e( 'Download', 'matthias-court' ); ?></span></a>
					<a class="mc-doclib__btn mc-doclib__btn--quiet" href="#" target="_blank" rel="noopener" data-doclib-pane-open><span><?php esc_html_e( 'Open in new tab', 'matthias-court' ); ?></span></a>
					<button type="button" class="mc-doclib__close" data-doclib-close aria-label="<?php esc_attr_e( 'Close preview', 'matthias-court' ); ?>"><?php echo $mc_ico['x']; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?></button>
				</div>
			</div>
			<iframe class="mc-doclib__frame" title="<?php esc_attr_e( 'Document preview', 'matthias-court' ); ?>" data-doclib-frame></iframe>
		</dialog>
	<?php endif; ?>
</div>
