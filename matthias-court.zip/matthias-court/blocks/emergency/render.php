<?php
/**
 * Emergency numbers strip.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$items = array(
	array( $attributes['fireLabel'], $attributes['fire'] ),
	array( $attributes['gasLabel'], $attributes['gas'] ),
	array( $attributes['outOfHoursLabel'], $attributes['outOfHours'] ),
);
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-emergency' ) ); ?>>
	<div class="mc-emergency__inner">
		<strong class="mc-emergency__title"><?php echo esc_html( $attributes['title'] ); ?></strong>
		<?php foreach ( $items as $item ) : ?>
			<?php if ( '' !== trim( (string) $item[1] ) && false === strpos( (string) $item[1], '[' ) ) : ?>
				<span class="mc-emergency__item"><?php echo esc_html( $item[0] ); ?> <b><?php echo esc_html( $item[1] ); ?></b></span>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
</div>
