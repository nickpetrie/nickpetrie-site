<?php
/**
 * Notices list: current notices, and optionally past ones.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_lists = array( array( 'current', mc_query_notices( $attributes['count'] ) ) );
if ( ! empty( $attributes['showEnded'] ) ) {
	$mc_lists[] = array( 'ended', mc_query_notices( 20, true ) );
}
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-notices' ) ); ?>>
	<?php foreach ( $mc_lists as $mc_list ) : ?>
		<?php list( $mc_kind, $mc_query ) = $mc_list; ?>
		<?php if ( 'ended' === $mc_kind ) : ?>
			<?php if ( ! $mc_query->have_posts() ) { continue; } ?>
			<h2 class="mc-notices__past"><?php echo esc_html( $attributes['pastHeading'] ); ?></h2>
		<?php endif; ?>
		<?php if ( $mc_query->have_posts() ) : ?>
			<ol class="mc-notices__list<?php echo 'ended' === $mc_kind ? ' mc-notices__list--ended' : ''; ?>">
				<?php
				while ( $mc_query->have_posts() ) :
					$mc_query->the_post();
					$mc_id = get_the_ID();
					?>
					<li class="mc-notice">
						<div class="mc-notice__meta">
							<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
							<?php echo mc_notice_status_html( $mc_id ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in helper. ?>
						</div>
						<div class="mc-notice__body">
							<h3 class="mc-notice__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<?php if ( has_excerpt() ) : ?>
								<p class="mc-notice__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
							<?php else : ?>
								<p class="mc-notice__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p>
							<?php endif; ?>
						</div>
					</li>
				<?php endwhile; ?>
			</ol>
		<?php elseif ( 'current' === $mc_kind ) : ?>
			<p class="mc-notices__empty"><?php echo esc_html( $attributes['emptyText'] ); ?></p>
		<?php endif; ?>
		<?php wp_reset_postdata(); ?>
	<?php endforeach; ?>
</div>
