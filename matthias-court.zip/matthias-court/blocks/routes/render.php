<?php
/**
 * "What do you need?" routes panel.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$routes = array(
	array( 'report', 'wrench', true ),
	array( 'guide', 'book', false ),
	array( 'contact', 'mail', false ),
);
$heading_id = wp_unique_id( 'mc-routes-' );
?>
<nav <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-routes' ) ); ?> aria-labelledby="<?php echo esc_attr( $heading_id ); ?>">
	<h2 class="mc-routes__heading" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $attributes['heading'] ); ?></h2>
	<ul class="mc-routes__list">
		<?php foreach ( $routes as $route ) : ?>
			<?php
			list( $key, $icon, $primary ) = $route;
			$title = $attributes[ $key . 'Title' ];
			if ( '' === trim( (string) $title ) ) {
				continue;
			}
			?>
			<li>
				<a class="mc-route<?php echo $primary ? ' mc-route--primary' : ''; ?>" href="<?php echo esc_url( $attributes[ $key . 'Url' ] ); ?>">
					<span class="mc-route__icon"><?php echo mc_icon( $icon ); // phpcs:ignore WordPress.Security.EscapeOutput -- fixed SVG. ?></span>
					<span class="mc-route__text">
						<span class="mc-route__title"><?php echo esc_html( $title ); ?></span>
						<span class="mc-route__desc"><?php echo esc_html( $attributes[ $key . 'Text' ] ); ?></span>
					</span>
					<span class="mc-route__chevron"><?php echo mc_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput -- fixed SVG. ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
