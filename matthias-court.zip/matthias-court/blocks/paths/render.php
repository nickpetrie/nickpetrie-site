<?php
/**
 * Decorative Richmond Park paths layer. Markup comes from the handoff template part.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_template_part( 'template-parts/richmond-paths' );
