<?php
/**
 * Latest documents: titles and dates of the newest files on the Documents
 * page. Only titles are shown here; the files stay behind the sign-in.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_page = get_page_by_path( trim( (string) $attributes['source'], '/' ) );
$mc_docs = $mc_page ? mc_documents_on_page( $mc_page ) : array();
$mc_docs = array_slice( $mc_docs, 0, max( 1, (int) $attributes['count'] ) );
$mc_link = $mc_page ? get_permalink( $mc_page ) : '';
$mc_lock = '<svg aria-hidden="true" focusable="false" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="5" y="11" width="14" height="9" rx="1"></rect><path d="M8 11V8a4 4 0 0 1 8 0v3"></path></svg>';
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-latest-docs' ) ); ?>>
	<?php if ( $mc_docs ) : ?>
		<ul class="mc-latest-docs__list">
			<?php foreach ( $mc_docs as $mc_doc ) : ?>
				<li>
					<a href="<?php echo esc_url( $mc_link ); ?>"><?php echo esc_html( $mc_doc['title'] ); ?></a>
					<span><?php echo esc_html( implode( ', ', array_filter( array( $mc_doc['group'], $mc_doc['date'] ? wp_date( 'j F Y', $mc_doc['date'] ) : '' ) ) ) ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p class="mc-latest-docs__empty"><?php echo esc_html( $attributes['emptyText'] ); ?></p>
	<?php endif; ?>
	<?php if ( $mc_link && '' !== trim( (string) $attributes['buttonLabel'] ) ) : ?>
		<a class="mc-latest-docs__all" href="<?php echo esc_url( $mc_link ); ?>"><?php echo $mc_lock; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed markup. ?> <?php echo esc_html( $attributes['buttonLabel'] ); ?></a>
	<?php endif; ?>
	<?php if ( '' !== trim( (string) $attributes['note'] ) ) : ?>
		<p class="mc-latest-docs__note"><?php echo esc_html( $attributes['note'] ); ?></p>
	<?php endif; ?>
</div>
