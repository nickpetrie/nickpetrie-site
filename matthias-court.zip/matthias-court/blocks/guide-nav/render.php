<?php
/**
 * Guide side menu with the current page marked.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_current = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : get_queried_object_id();
$mc_groups  = mc_guide_groups( $attributes['parentSlug'], $mc_current, $attributes['moreLabel'] );
$mc_parent  = mc_guide_parent( $attributes['parentSlug'], $mc_current );
if ( ! $mc_groups || ! $mc_parent ) {
	return;
}
?>
<nav <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-guide-nav' ) ); ?> aria-label="<?php echo esc_attr( get_the_title( $mc_parent ) ); ?>">
	<a class="mc-guide-nav__parent" href="<?php echo esc_url( get_permalink( $mc_parent ) ); ?>"><?php echo esc_html( get_the_title( $mc_parent ) ); ?></a>
	<?php foreach ( $mc_groups as $mc_group ) : ?>
		<p class="mc-guide-nav__group"><?php echo esc_html( $mc_group['name'] ); ?></p>
		<ul>
			<?php foreach ( $mc_group['pages'] as $mc_page ) : ?>
				<li>
					<a href="<?php echo esc_url( get_permalink( $mc_page ) ); ?>"<?php echo $mc_page->ID === $mc_current ? ' aria-current="page"' : ''; ?>><?php echo esc_html( get_the_title( $mc_page ) ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endforeach; ?>
</nav>
