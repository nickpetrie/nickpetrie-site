<?php
/**
 * A single notice's status, date and end date.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_id = isset( $block->context['postId'] ) ? (int) $block->context['postId'] : get_the_ID();
if ( ! $mc_id ) {
	return;
}
$mc_end = get_post_meta( $mc_id, 'mc_end_date', true );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-notice-meta' ) ); ?>>
	<?php echo mc_notice_status_html( $mc_id ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in helper. ?>
	<span><?php echo esc_html( $attributes['postedLabel'] ); ?> <time datetime="<?php echo esc_attr( get_the_date( 'c', $mc_id ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y', $mc_id ) ); ?></time></span>
	<?php if ( get_the_modified_date( 'Y-m-d', $mc_id ) !== get_the_date( 'Y-m-d', $mc_id ) ) : ?>
		<span><?php echo esc_html( $attributes['updatedLabel'] ); ?> <time datetime="<?php echo esc_attr( get_the_modified_date( 'c', $mc_id ) ); ?>"><?php echo esc_html( get_the_modified_date( 'j F Y', $mc_id ) ); ?></time></span>
	<?php endif; ?>
	<?php if ( $mc_end ) : ?>
		<span>
			<?php
			$mc_end_label = mc_notice_has_ended( $mc_id ) ? $attributes['endedLabel'] : $attributes['untilLabel'];
			echo esc_html( $mc_end_label ) . ' ';
			?>
			<time datetime="<?php echo esc_attr( $mc_end ); ?>"><?php echo esc_html( wp_date( 'j F Y', strtotime( $mc_end . ' 12:00:00' ) ) ); ?></time>
		</span>
	<?php endif; ?>
</div>
