<?php
/**
 * Next AGM strip. Shows nothing without a date, or once the day has passed.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mc_is_editor = is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST );
$mc_date      = trim( (string) $attributes['date'] );
$mc_time      = trim( (string) $attributes['time'] );
$mc_ts        = $mc_date ? strtotime( $mc_date . ' ' . ( $mc_time ? $mc_time : '19:00' ) . ' ' . wp_timezone_string() ) : false;
if ( ! $mc_ts || wp_date( 'Y-m-d', $mc_ts ) < wp_date( 'Y-m-d' ) ) {
	if ( $mc_is_editor ) {
		echo '<p class="mc-agm-hint">' . esc_html__( 'Next AGM: set the date in the block settings. The strip hides itself once the date has passed.', 'matthias-court' ) . '</p>';
	}
	return;
}
$mc_online = 'online' === $attributes['mode'];
$mc_when   = wp_date( 'l j F Y', $mc_ts ) . ( $mc_time ? ', ' . str_replace( ':00', '', wp_date( 'g:ia', $mc_ts ) ) : '' );
$mc_where  = $mc_online ? $attributes['onlineText'] : $attributes['location'];
$mc_action = '';
if ( $mc_online && '' !== trim( (string) $attributes['link'] ) ) {
	$mc_action = '<a class="mc-agm__action" href="' . esc_url( $attributes['link'] ) . '">' . esc_html( $attributes['joinLabel'] ) . '</a>';
} elseif ( '' !== trim( (string) $attributes['calendarLabel'] ) ) {
	$mc_ics    = implode(
		"\r\n",
		array(
			'BEGIN:VCALENDAR',
			'VERSION:2.0',
			'PRODID:-//Matthias Court//AGM//EN',
			'BEGIN:VEVENT',
			'UID:agm-' . gmdate( 'Ymd', $mc_ts ) . '@matthiascourt.co.uk',
			'DTSTAMP:' . gmdate( 'Ymd\THis\Z' ),
			'DTSTART:' . gmdate( 'Ymd\THis\Z', $mc_ts ),
			'DTEND:' . gmdate( 'Ymd\THis\Z', $mc_ts + 2 * HOUR_IN_SECONDS ),
			'SUMMARY:Matthias Court AGM',
			'LOCATION:' . str_replace( array( ',', ';' ), array( '\,', '\;' ), $mc_online ? (string) $attributes['link'] : (string) $mc_where ),
			'END:VEVENT',
			'END:VCALENDAR',
		)
	);
	$mc_action = '<a class="mc-agm__action" download="matthias-court-agm.ics" href="data:text/calendar;charset=utf-8,' . rawurlencode( $mc_ics ) . '">' . esc_html( $attributes['calendarLabel'] ) . '</a>';
}
?>
<section <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-agm alignfull' ) ); ?> aria-label="<?php echo esc_attr( $attributes['label'] ); ?>">
	<div class="mc-agm__inner">
		<p class="mc-agm__when"><?php echo esc_html( $attributes['label'] . ': ' . $mc_when ); ?></p>
		<p class="mc-agm__where"><?php echo esc_html( trim( $mc_where . '. ' . $attributes['note'], ' .' ) . '.' ); ?></p>
		<?php echo $mc_action; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts above. ?>
	</div>
</section>
