<?php
/**
 * Monogram and site name.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$name = get_bloginfo( 'name' );
?>
<a <?php echo get_block_wrapper_attributes( array( 'class' => 'mc-brand' ) ); ?> href="<?php echo esc_url( home_url( '/' ) ); ?>">
	<span class="mc-brand__mark" aria-hidden="true">MC</span>
	<span class="mc-brand__name"><?php echo esc_html( $name ); ?></span>
</a>
