<?php
/** Decorative layer. Place inside a positioned .mc-richmond-hero wrapper. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="mc-richmond-paths" data-paused="true">
    <?php
    // Fixed, reviewed theme asset only. Never replace this path with user input.
    require get_theme_file_path( '/assets/richmond-paths/artwork.svg' );
    ?>
    <button class="mcrp-toggle" type="button" aria-pressed="false"
        aria-label="<?php esc_attr_e( 'Pause animation', 'matthias-court' ); ?>"
        data-pause-label="<?php esc_attr_e( 'Pause animation', 'matthias-court' ); ?>"
        data-resume-label="<?php esc_attr_e( 'Resume animation', 'matthias-court' ); ?>" hidden>
        <svg class="mcrp-icon mcrp-icon--pause" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><rect x="4" y="3" width="3" height="10" rx=".5"/><rect x="9" y="3" width="3" height="10" rx=".5"/></svg>
        <svg class="mcrp-icon mcrp-icon--play" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M5 3.2 L13 8 L5 12.8 Z"/></svg>
    </button>
</div>
