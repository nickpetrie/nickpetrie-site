<?php
/** Decorative layer. Place inside a positioned .mc-richmond-hero wrapper. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="mc-richmond-paths" data-paused="true">
    <?php
    // Fixed, reviewed theme asset only. Never replace this path with user input.
    require get_theme_file_path( '/assets/richmond-paths/artwork.svg' );
    ?>
    <button class="mcrp-toggle" type="button" aria-pressed="false"
        data-pause-label="<?php esc_attr_e( 'Pause animation', 'matthias-court' ); ?>"
        data-resume-label="<?php esc_attr_e( 'Resume animation', 'matthias-court' ); ?>" hidden>
        <?php esc_html_e( 'Pause animation', 'matthias-court' ); ?>
    </button>
</div>
