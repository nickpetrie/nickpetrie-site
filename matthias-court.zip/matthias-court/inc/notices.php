<?php
/**
 * Notices: posts relabelled as notices, with a status and an optional end date.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The statuses a notice can carry. Key => label.
 */
function mc_notice_statuses() {
	return array(
		'underway' => __( 'Under way', 'matthias-court' ),
		'action'   => __( 'Action needed', 'matthias-court' ),
		'planned'  => __( 'Planned', 'matthias-court' ),
		'info'     => __( 'For information', 'matthias-court' ),
	);
}

function mc_register_notice_meta() {
	$auth = function () {
		return current_user_can( 'edit_posts' );
	};
	register_post_meta(
		'post',
		'mc_status',
		array(
			'type'              => 'string',
			'single'            => true,
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) {
				return array_key_exists( $value, mc_notice_statuses() ) ? $value : '';
			},
			'auth_callback'     => $auth,
		)
	);
	register_post_meta(
		'post',
		'mc_end_date',
		array(
			'type'              => 'string',
			'single'            => true,
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) {
				return preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $value ) ? $value : '';
			},
			'auth_callback'     => $auth,
		)
	);
}
add_action( 'init', 'mc_register_notice_meta' );

/**
 * Call posts "Notices" throughout the dashboard.
 */
function mc_notice_labels( $labels ) {
	$labels->name                  = __( 'Notices', 'matthias-court' );
	$labels->singular_name         = __( 'Notice', 'matthias-court' );
	$labels->add_new               = __( 'Add notice', 'matthias-court' );
	$labels->add_new_item          = __( 'Add notice', 'matthias-court' );
	$labels->edit_item             = __( 'Edit notice', 'matthias-court' );
	$labels->new_item              = __( 'New notice', 'matthias-court' );
	$labels->view_item             = __( 'View notice', 'matthias-court' );
	$labels->view_items            = __( 'View notices', 'matthias-court' );
	$labels->search_items          = __( 'Search notices', 'matthias-court' );
	$labels->not_found             = __( 'No notices found', 'matthias-court' );
	$labels->not_found_in_trash    = __( 'No notices in the bin', 'matthias-court' );
	$labels->all_items             = __( 'All notices', 'matthias-court' );
	$labels->menu_name             = __( 'Notices', 'matthias-court' );
	$labels->name_admin_bar        = __( 'Notice', 'matthias-court' );
	$labels->item_published        = __( 'Notice published.', 'matthias-court' );
	$labels->item_updated          = __( 'Notice updated.', 'matthias-court' );
	return $labels;
}
add_filter( 'post_type_labels_post', 'mc_notice_labels' );

function mc_notice_menu_icon( $args, $post_type ) {
	if ( 'post' === $post_type ) {
		$args['menu_icon'] = 'dashicons-megaphone';
	}
	return $args;
}
add_filter( 'register_post_type_args', 'mc_notice_menu_icon', 10, 2 );

/**
 * Today's date in the site's timezone, as Y-m-d.
 */
function mc_today() {
	return wp_date( 'Y-m-d' );
}

/**
 * Whether a notice has passed its end date.
 */
function mc_notice_has_ended( $post_id ) {
	$end = get_post_meta( $post_id, 'mc_end_date', true );
	return $end && $end < mc_today();
}

/**
 * Query notices that are current (no end date, or ending today or later),
 * or, with $ended, those that have ended.
 */
function mc_query_notices( $count = 3, $ended = false ) {
	$today = mc_today();
	if ( $ended ) {
		$meta = array(
			array( 'key' => 'mc_end_date', 'value' => '', 'compare' => '!=' ),
			array( 'key' => 'mc_end_date', 'value' => $today, 'compare' => '<', 'type' => 'DATE' ),
		);
	} else {
		$meta = array(
			'relation' => 'OR',
			array( 'key' => 'mc_end_date', 'compare' => 'NOT EXISTS' ),
			array( 'key' => 'mc_end_date', 'value' => '' ),
			array( 'key' => 'mc_end_date', 'value' => $today, 'compare' => '>=', 'type' => 'DATE' ),
		);
	}
	return new WP_Query(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $count ),
			'ignore_sticky_posts' => false,
			'no_found_rows'       => true,
			'meta_query'          => $meta, // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
}

/**
 * Markup for a notice's status, used in lists and on the notice itself.
 */
function mc_notice_status_html( $post_id ) {
	$statuses = mc_notice_statuses();
	if ( mc_notice_has_ended( $post_id ) ) {
		return '<span class="mc-status mc-status--ended"><span class="mc-status__dot" aria-hidden="true"></span>' . esc_html__( 'Ended', 'matthias-court' ) . '</span>';
	}
	$status = get_post_meta( $post_id, 'mc_status', true );
	if ( ! $status || ! isset( $statuses[ $status ] ) ) {
		return '';
	}
	return sprintf(
		'<span class="mc-status mc-status--%1$s"><span class="mc-status__dot" aria-hidden="true"></span>%2$s</span>',
		esc_attr( $status ),
		esc_html( $statuses[ $status ] )
	);
}
