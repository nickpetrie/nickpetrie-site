<?php
/**
 * The residents' guide: child pages of "Living here", sorted into groups.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mc_register_guide_groups() {
	register_taxonomy(
		'mc_guide_group',
		'page',
		array(
			'labels'            => array(
				'name'          => __( 'Guide groups', 'matthias-court' ),
				'singular_name' => __( 'Guide group', 'matthias-court' ),
				'menu_name'     => __( 'Guide groups', 'matthias-court' ),
				'all_items'     => __( 'All guide groups', 'matthias-court' ),
				'add_new_item'  => __( 'Add guide group', 'matthias-court' ),
			),
			'hierarchical'      => true,
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => false,
		)
	);
}
add_action( 'init', 'mc_register_guide_groups' );

/**
 * The guide's parent page. An empty slug means "this section": the current
 * page if it has guide pages under it, otherwise its top-level ancestor.
 */
function mc_guide_parent( $slug = '', $post_id = 0 ) {
	if ( '' !== trim( (string) $slug ) ) {
		return get_page_by_path( trim( $slug, '/' ) );
	}
	$post_id = $post_id ? $post_id : get_queried_object_id();
	$post    = $post_id ? get_post( $post_id ) : null;
	if ( ! $post || 'page' !== $post->post_type ) {
		return get_page_by_path( 'living-here' );
	}
	if ( get_pages( array( 'parent' => $post->ID, 'number' => 1 ) ) ) {
		return $post;
	}
	$ancestors = get_post_ancestors( $post );
	return $ancestors ? get_post( end( $ancestors ) ) : $post;
}

/**
 * Guide pages grouped for display: array of [ 'name' => string, 'pages' => WP_Post[] ].
 * Groups follow the agreed order; any other groups follow alphabetically,
 * and pages with no group come last under "More".
 */
function mc_guide_groups( $slug = '', $post_id = 0, $more_label = '' ) {
	$more_label = '' !== $more_label ? $more_label : __( 'More', 'matthias-court' );
	$parent = mc_guide_parent( $slug, $post_id );
	if ( ! $parent ) {
		return array();
	}
	$pages = get_pages(
		array(
			'parent'      => $parent->ID,
			'sort_column' => 'menu_order,post_title',
			'post_status' => 'publish',
		)
	);
	$order  = array( 'everyday', 'safety-and-security', 'your-flat', 'the-building', 'owning-your-flat', 'changing-or-selling', 'how-the-building-is-run' );
	$groups = array();
	$other  = array();
	foreach ( $pages as $page ) {
		if ( 'page-members' === get_page_template_slug( $page ) ) {
			continue;
		}
		$terms = get_the_terms( $page, 'mc_guide_group' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$term = $terms[0];
			if ( ! isset( $groups[ $term->slug ] ) ) {
				$groups[ $term->slug ] = array( 'name' => $term->name, 'pages' => array() );
			}
			$groups[ $term->slug ]['pages'][] = $page;
		} else {
			$other[] = $page;
		}
	}
	uksort(
		$groups,
		function ( $a, $b ) use ( $order, $groups ) {
			$ia = array_search( $a, $order, true );
			$ib = array_search( $b, $order, true );
			$ia = false === $ia ? 100 : $ia;
			$ib = false === $ib ? 100 : $ib;
			return $ia === $ib ? strcmp( $groups[ $a ]['name'], $groups[ $b ]['name'] ) : $ia - $ib;
		}
	);
	$groups = array_values( $groups );
	if ( $other ) {
		$groups[] = array( 'name' => $more_label, 'pages' => $other );
	}
	return $groups;
}

/**
 * Pages get an excerpt box: on section pages it is the intro under the title.
 */
add_action( 'init', function () {
	add_post_type_support( 'page', 'excerpt' );
} );

/**
 * A chevron-list look for the guide contents, used on the leaseholders page.
 */
add_action( 'init', function () {
	register_block_style( 'matthias-court/guide-index', array( 'name' => 'chevrons', 'label' => __( 'Chevron list', 'matthias-court' ) ) );
} );
