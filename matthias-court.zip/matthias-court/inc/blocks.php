<?php
/**
 * The theme's server-rendered blocks and the editor script that drives them.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mc_register_blocks() {
	$path = '/assets/js/editor.js';
	wp_register_script(
		'mc-editor',
		get_theme_file_uri( $path ),
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n' ),
		(string) filemtime( get_theme_file_path( $path ) ),
		true
	);
	foreach ( array( 'paths', 'emergency', 'brand', 'routes', 'notices', 'notice-meta', 'guide-index', 'guide-nav', 'agm', 'latest-documents' ) as $block ) {
		register_block_type( get_theme_file_path( '/blocks/' . $block ) );
	}
}
add_action( 'init', 'mc_register_blocks' );

/**
 * Notice settings panel in the post editor.
 */
function mc_enqueue_notice_panel() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'post' !== $screen->post_type ) {
		return;
	}
	$path = '/assets/js/notice-panel.js';
	wp_enqueue_script(
		'mc-notice-panel',
		get_theme_file_uri( $path ),
		array( 'wp-plugins', 'wp-editor', 'wp-element', 'wp-components', 'wp-data', 'wp-i18n' ),
		(string) filemtime( get_theme_file_path( $path ) ),
		true
	);
	$statuses = array();
	foreach ( mc_notice_statuses() as $value => $label ) {
		$statuses[] = array( 'value' => $value, 'label' => $label );
	}
	wp_add_inline_script( 'mc-notice-panel', 'window.mcNoticeStatuses = ' . wp_json_encode( $statuses ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'mc_enqueue_notice_panel' );

/**
 * Inline SVG icons used by the theme's blocks. Fixed markup, no user input.
 */
function mc_icon( $name ) {
	$icons = array(
		'wrench'  => '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17v3h3l5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"></path>',
		'book'    => '<path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5z"></path><path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H13v16h5.5a1.5 1.5 0 0 0 1.5-1.5z"></path>',
		'mail'    => '<path d="M4 6h16v12H4z"></path><path d="M4 7l8 6 8-6"></path>',
		'chevron' => '<path d="M9 6l6 6-6 6"></path>',
	);
	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}
	return '<svg aria-hidden="true" focusable="false" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $icons[ $name ] . '</svg>';
}
