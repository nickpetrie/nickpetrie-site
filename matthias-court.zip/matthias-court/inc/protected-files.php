<?php
/**
 * Leaseholder documents: files uploaded to a leaseholders-only page get an unguessable
 * address, and WordPress stops pointing strangers to them.
 *
 * WordPress.com serves uploads directly, so a file cannot be locked behind a login.
 * Instead: the file name is random (so it cannot be guessed or found), its link only
 * appears on the sign-in page, and the usual back doors (attachment pages, the media
 * API) do not reveal it to anyone who is not signed in.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The page an upload is being attached to, if WordPress tells us.
 */
function mc_upload_parent_id() {
	foreach ( array( 'post', 'post_id' ) as $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification -- read-only check; the upload itself is verified by WordPress.
		if ( isset( $_REQUEST[ $key ] ) && is_numeric( $_REQUEST[ $key ] ) ) {
			return (int) $_REQUEST[ $key ];
		}
	}
	return 0;
}

/**
 * Whether an attachment belongs to a leaseholders-only page.
 */
function mc_is_protected_attachment( $attachment ) {
	$attachment = get_post( $attachment );
	if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
		return false;
	}
	if ( get_post_meta( $attachment->ID, '_mc_protected', true ) ) {
		return true;
	}
	return $attachment->post_parent && mc_is_members_page( $attachment->post_parent );
}

/**
 * Give files uploaded to a leaseholders-only page a random name, keeping the extension.
 */
function mc_protect_upload_name( $file ) {
	$parent = mc_upload_parent_id();
	if ( ! $parent || ! mc_is_members_page( $parent ) || ! empty( $file['error'] ) ) {
		return $file;
	}
	$GLOBALS['mc_protected_upload_title'] = pathinfo( $file['name'], PATHINFO_FILENAME );
	$ext          = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
	$file['name'] = 'mc-' . wp_generate_password( 32, false, false ) . ( $ext ? '.' . $ext : '' );
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'mc_protect_upload_name' );
add_filter( 'wp_handle_sideload_prefilter', 'mc_protect_upload_name' );

/**
 * Keep the human file name as the document title, and mark the file as protected.
 */
function mc_protect_upload_title( $data ) {
	if ( ! empty( $GLOBALS['mc_protected_upload_title'] ) && 'attachment' === $data['post_type'] ) {
		$data['post_title'] = sanitize_text_field( str_replace( array( '-', '_' ), ' ', $GLOBALS['mc_protected_upload_title'] ) );
		// The slug must not echo the file name, or the attachment address would give it away.
		$data['post_name'] = 'document-' . strtolower( wp_generate_password( 12, false, false ) );
	}
	return $data;
}
add_filter( 'wp_insert_attachment_data', 'mc_protect_upload_title' );

add_action(
	'add_attachment',
	function ( $id ) {
		if ( ! empty( $GLOBALS['mc_protected_upload_title'] ) ) {
			update_post_meta( $id, '_mc_protected', 1 );
			unset( $GLOBALS['mc_protected_upload_title'] );
		}
	}
);

/**
 * No attachment page (which would redirect to the file) for people who are not signed in.
 */
add_action(
	'template_redirect',
	function () {
		if ( is_attachment() && mc_is_protected_attachment( get_queried_object_id() ) && ! mc_is_leaseholder() ) {
			remove_action( 'template_redirect', 'redirect_canonical' );
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	},
	1
);

/**
 * The media API does not list protected files for people who are not signed in.
 */
add_filter(
	'rest_attachment_query',
	function ( $args ) {
		if ( mc_is_leaseholder() ) {
			return $args;
		}
		$args['meta_query']   = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array();
		$args['meta_query'][] = array(
			'key'     => '_mc_protected',
			'compare' => 'NOT EXISTS',
		);
		$members = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => 'page-members', // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( $members ) {
			$args['post_parent__not_in'] = array_merge( isset( $args['post_parent__not_in'] ) ? (array) $args['post_parent__not_in'] : array(), $members );
		}
		return $args;
	}
);

add_filter(
	'rest_prepare_attachment',
	function ( $response, $post ) {
		if ( ! mc_is_leaseholder() && mc_is_protected_attachment( $post ) && $response instanceof WP_REST_Response ) {
			$data = $response->get_data();
			foreach ( array( 'source_url', 'link', 'slug' ) as $key ) {
				$data[ $key ] = '';
			}
			foreach ( array( 'guid', 'title', 'description', 'caption' ) as $key ) {
				$data[ $key ] = array( 'rendered' => '' );
			}
			$data['media_details'] = new stdClass();
			$response->set_data( $data );
			$response->remove_link( 'self' );
		}
		return $response;
	},
	10,
	2
);
