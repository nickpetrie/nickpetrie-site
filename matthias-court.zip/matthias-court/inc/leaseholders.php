<?php
/**
 * Leaseholder area: the documents list and the sign-in gate.
 *
 * Pages using the "Leaseholders only" template show their content only to
 * signed-in leaseholders (Simple Membership members) and site editors.
 * Everyone else sees the "Leaseholder sign-in" template part instead.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current visitor can see leaseholder-only pages.
 */
function mc_is_leaseholder() {
	if ( is_user_logged_in() ) {
		return true;
	}
	if ( class_exists( 'SwpmMemberUtils' ) && method_exists( 'SwpmMemberUtils', 'is_member_logged_in' ) && SwpmMemberUtils::is_member_logged_in() ) {
		return true;
	}
	return false;
}

/**
 * Whether a page is leaseholders-only.
 */
function mc_is_members_page( $post ) {
	$post = get_post( $post );
	return $post && 'page' === $post->post_type && 'page-members' === get_page_template_slug( $post );
}

/**
 * The sign-in panel shown in place of a leaseholders-only page.
 */
function mc_members_gate_html() {
	$part    = get_block_template( get_stylesheet() . '//members-gate', 'wp_template_part' );
	$content = $part && ! empty( $part->content ) ? $part->content : '';
	$html    = do_blocks( $content );
	if ( ! shortcode_exists( 'swpm_login_form' ) ) {
		$html = str_replace( '[swpm_login_form]', wp_login_form( array( 'echo' => false, 'redirect' => get_permalink() ) ), $html );
	}
	return '<div class="mc-gate">' . do_shortcode( $html ) . '</div>';
}

function mc_members_filter_content( $content ) {
	$post = get_post();
	if ( $post && mc_is_members_page( $post ) && ! mc_is_leaseholder() ) {
		remove_filter( 'the_content', 'mc_members_filter_content', 1 );
		$gate = mc_members_gate_html();
		add_filter( 'the_content', 'mc_members_filter_content', 1 );
		return $gate;
	}
	return $content;
}
add_filter( 'the_content', 'mc_members_filter_content', 1 );

add_filter(
	'get_the_excerpt',
	function ( $excerpt, $post ) {
		// Only the excerpt typed into the page is shown; never one made from the content.
		return mc_is_members_page( $post ) && ! mc_is_leaseholder() ? get_post_field( 'post_excerpt', $post ) : $excerpt;
	},
	20,
	2
);

add_filter(
	'rest_prepare_page',
	function ( $response, $post ) {
		if ( mc_is_members_page( $post ) && ! mc_is_leaseholder() ) {
			$data = $response->get_data();
			if ( isset( $data['content'] ) ) {
				$data['content'] = array( 'rendered' => '', 'protected' => true );
			}
			if ( isset( $data['excerpt'] ) ) {
				$data['excerpt'] = array( 'rendered' => '', 'protected' => true );
			}
			$response->set_data( $data );
		}
		return $response;
	},
	10,
	2
);

/**
 * Keep leaseholder-only pages out of the site search for everyone else.
 */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() || mc_is_leaseholder() ) {
			return;
		}
		$query->set(
			'meta_query',
			array(
				'relation' => 'OR',
				array( 'key' => '_wp_page_template', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_wp_page_template', 'value' => 'page-members', 'compare' => '!=' ),
			)
		);
	}
);

/**
 * Files on a page, newest first: [ title, group, date ]. The group is the
 * nearest heading above the file, so headings on the Documents page
 * ("Newsletters", "JCF circulars") double as categories.
 */
function mc_documents_on_page( $page ) {
	$docs  = array();
	$group = '';
	$walk  = function ( $blocks ) use ( &$walk, &$docs, &$group ) {
		foreach ( $blocks as $block ) {
			if ( 'core/heading' === $block['blockName'] ) {
				$group = trim( wp_strip_all_tags( $block['innerHTML'] ) );
			} elseif ( 'core/file' === $block['blockName'] ) {
				$id    = isset( $block['attrs']['id'] ) ? (int) $block['attrs']['id'] : 0;
				$title = '';
				if ( preg_match( '#<a(?![^>]*wp-block-file__button)[^>]*>(.*?)</a>#s', $block['innerHTML'], $m ) ) {
					$title = trim( wp_strip_all_tags( $m[1] ) );
				}
				if ( '' === $title && $id ) {
					$title = get_the_title( $id );
				}
				if ( '' !== $title ) {
					$docs[] = array(
						'title' => html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ),
						'group' => $group,
						'date'  => $id ? (int) get_post_time( 'U', true, $id ) : 0,
						'order' => count( $docs ),
					);
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$walk( $block['innerBlocks'] );
			}
		}
	};
	$walk( parse_blocks( get_post_field( 'post_content', $page ) ) );
	usort(
		$docs,
		function ( $a, $b ) {
			return $a['date'] === $b['date'] ? $a['order'] - $b['order'] : $b['date'] - $a['date'];
		}
	);
	return $docs;
}
