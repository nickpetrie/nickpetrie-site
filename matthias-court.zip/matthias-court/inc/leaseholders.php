<?php
/**
 * Leaseholder area: the documents list and the sign-in gate.
 *
 * Pages using the "Leaseholders only" template show their content only to
 * signed-in leaseholders (Simple Membership members) and site editors.
 * Everyone else sees the "Leaseholder sign-in" template part instead.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the current visitor can see leaseholder-only pages.
 */
function mc_is_leaseholder() {
	if ( is_user_logged_in() ) {
		return true;
	}
	if ( class_exists( 'SwpmMemberUtils' ) && method_exists( 'SwpmMemberUtils', 'is_member_logged_in' ) && SwpmMemberUtils::is_member_logged_in() ) {
		// Only members on the Leaseholder level: a Resident account does not open leaseholder pages.
		$allowed = array_map( 'strtolower', (array) apply_filters( 'mc_leaseholder_levels', array( 'Leaseholder' ) ) );
		return in_array( strtolower( mc_swpm_member_level_name() ), $allowed, true );
	}
	return false;
}

/**
 * The name of the signed-in Simple Membership member's level, or '' if it can't be found.
 */
function mc_swpm_member_level_name() {
	static $name = null;
	if ( null !== $name ) {
		return $name;
	}
	$name     = '';
	$level_id = 0;
	if ( method_exists( 'SwpmMemberUtils', 'get_logged_in_members_level' ) ) {
		$level_id = (int) SwpmMemberUtils::get_logged_in_members_level();
	} elseif ( class_exists( 'SwpmAuth' ) ) {
		$auth = SwpmAuth::get_instance();
		if ( $auth && $auth->is_logged_in() ) {
			$level_id = (int) $auth->get( 'membership_level' );
		}
	}
	if ( $level_id > 0 ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- the plugin keeps levels in its own table.
		$name = (string) $wpdb->get_var( $wpdb->prepare( "SELECT alias FROM {$wpdb->prefix}swpm_membership_tbl WHERE id = %d", $level_id ) );
	}
	return $name;
}

/**
 * Whether a page is leaseholders-only.
 */
function mc_is_members_page( $post ) {
	$post = get_post( $post );
	return $post && 'page' === $post->post_type && in_array( (int) $post->ID, mc_members_page_ids(), true );
}

/**
 * Every leaseholder-only page: those using the "Leaseholders only" template, and every page
 * beneath one (so the guides under Leaseholders keep the normal guide layout and stay private).
 */
function mc_members_page_ids() {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}
	$roots = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'any',
			'fields'         => 'ids',
			'posts_per_page' => -1,
			'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => 'page-members', // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	$ids = array_map( 'intval', $roots );
	foreach ( $roots as $root ) {
		$children = get_pages(
			array(
				'child_of'    => $root,
				'post_status' => 'publish,draft,private,pending,future',
			)
		);
		foreach ( $children as $child ) {
			$ids[] = (int) $child->ID;
		}
	}
	$ids = array_values( array_unique( $ids ) );
	return $ids;
}

/**
 * The sign-in panel shown in place of a leaseholders-only page.
 */
function mc_members_gate_html() {
	$part    = get_block_template( get_stylesheet() . '//members-gate', 'wp_template_part' );
	$content = $part && ! empty( $part->content ) ? $part->content : '';
	$html    = do_blocks( $content );
	if ( ! shortcode_exists( 'swpm_login_form' ) ) {
		$html = str_replace( '[swpm_login_form]', wp_login_form( array( 'echo' => false, 'redirect' => get_permalink() ) ), $html );
	}
	return '<div class="mc-gate">' . do_shortcode( $html ) . '</div>';
}

function mc_members_filter_content( $content ) {
	$post = get_post();
	if ( $post && mc_is_members_page( $post ) && ! mc_is_leaseholder() ) {
		remove_filter( 'the_content', 'mc_members_filter_content', 1 );
		$gate = mc_members_gate_html();
		add_filter( 'the_content', 'mc_members_filter_content', 1 );
		return $gate;
	}
	return $content;
}
add_filter( 'the_content', 'mc_members_filter_content', 1 );

add_filter(
	'get_the_excerpt',
	function ( $excerpt, $post ) {
		// Only the excerpt typed into the page is shown; never one made from the content.
		return mc_is_members_page( $post ) && ! mc_is_leaseholder() ? get_post_field( 'post_excerpt', $post ) : $excerpt;
	},
	20,
	2
);

add_filter(
	'rest_prepare_page',
	function ( $response, $post ) {
		if ( mc_is_members_page( $post ) && ! mc_is_leaseholder() ) {
			$data = $response->get_data();
			if ( isset( $data['content'] ) ) {
				$data['content'] = array( 'rendered' => '', 'protected' => true );
			}
			if ( isset( $data['excerpt'] ) ) {
				$data['excerpt'] = array( 'rendered' => '', 'protected' => true );
			}
			$response->set_data( $data );
		}
		return $response;
	},
	10,
	2
);

/**
 * Keep leaseholder-only pages out of the site search for everyone else.
 */
add_action(
	'pre_get_posts',
	function ( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() || mc_is_leaseholder() ) {
			return;
		}
		$ids = mc_members_page_ids();
		if ( $ids ) {
			$query->set( 'post__not_in', array_merge( (array) $query->get( 'post__not_in' ), $ids ) );
		}
	}
);

/**
 * Files on a page, newest first: [ title, group, date ]. The group is the
 * nearest heading above the file, so headings on the Documents page
 * ("Newsletters", "JCF circulars") double as categories.
 */
function mc_documents_on_page( $page ) {
	$docs  = array();
	$group = '';
	$walk  = function ( $blocks ) use ( &$walk, &$docs, &$group ) {
		foreach ( $blocks as $block ) {
			if ( 'core/heading' === $block['blockName'] ) {
				$group = trim( wp_strip_all_tags( $block['innerHTML'] ) );
			} elseif ( 'core/file' === $block['blockName'] ) {
				$id    = isset( $block['attrs']['id'] ) ? (int) $block['attrs']['id'] : 0;
				$title = '';
				if ( preg_match( '#<a(?![^>]*wp-block-file__button)[^>]*>(.*?)</a>#s', $block['innerHTML'], $m ) ) {
					$title = trim( wp_strip_all_tags( $m[1] ) );
				}
				if ( '' === $title && $id ) {
					$title = get_the_title( $id );
				}
				if ( '' !== $title ) {
					$url = '';
					if ( preg_match( '#href="([^"]+)"#', $block['innerHTML'], $h ) ) {
						$url = html_entity_decode( $h[1], ENT_QUOTES, 'UTF-8' );
					}
					if ( '' === $url && $id ) {
						$url = (string) wp_get_attachment_url( $id );
					}
					// The document's own date: a date typed into the file's Caption in the media library
					// (e.g. "2025-06-15" or "15 June 2025"), otherwise the day it was uploaded.
					$date    = $id ? (int) get_post_time( 'U', true, $id ) : 0;
					$caption = $id ? trim( wp_strip_all_tags( wp_get_attachment_caption( $id ) ) ) : '';
					if ( '' !== $caption ) {
						$parsed = strtotime( $caption );
						if ( false !== $parsed ) {
							$date = $parsed;
						}
					}
					$meta   = $id ? wp_get_attachment_metadata( $id ) : array();
					$size   = is_array( $meta ) && ! empty( $meta['filesize'] ) ? (int) $meta['filesize'] : 0;
					$type   = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
					$docs[] = array(
						'id'    => $id,
						'title' => html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ),
						'group' => $group,
						'date'  => $date,
						'url'   => $url,
						'type'  => $type,
						'size'  => $size,
						'desc'  => $id ? trim( wp_strip_all_tags( get_post_field( 'post_content', $id ) ) ) : '',
						'order' => count( $docs ),
					);
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$walk( $block['innerBlocks'] );
			}
		}
	};
	$walk( parse_blocks( get_post_field( 'post_content', $page ) ) );
	usort(
		$docs,
		function ( $a, $b ) {
			return $a['date'] === $b['date'] ? $a['order'] - $b['order'] : $b['date'] - $a['date'];
		}
	);
	return $docs;
}

/**
 * Never let a page cache serve a leaseholder-only page: the same address shows the sign-in box
 * to the public and the content to signed-in leaseholders (including Simple Membership logins,
 * which a WordPress page cache does not recognise).
 */
add_action(
	'template_redirect',
	function () {
		if ( is_singular( 'page' ) && mc_is_members_page( get_queried_object_id() ) ) {
			nocache_headers();
			header( 'Cache-Control: private, no-store, max-age=0', true );
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
		}
	},
	0
);

/**
 * Share and search descriptions for a leaseholder-only page never come from its content
 * (Jetpack builds them from the page text by default). Only the typed excerpt is used.
 */
function mc_members_description() {
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post || ! mc_is_members_page( $post ) ) {
		return null;
	}
	$excerpt = trim( wp_strip_all_tags( $post->post_excerpt ) );
	return '' !== $excerpt ? $excerpt : __( 'Leaseholder sign-in', 'matthias-court' );
}
add_filter(
	'jetpack_open_graph_tags',
	function ( $tags ) {
		$desc = is_singular( 'page' ) ? mc_members_description() : null;
		if ( null !== $desc ) {
			$tags['og:description'] = $desc;
			if ( isset( $tags['twitter:description'] ) ) {
				$tags['twitter:description'] = $desc;
			}
			unset( $tags['og:image'], $tags['og:image:width'], $tags['og:image:height'], $tags['og:image:alt'] );
		}
		return $tags;
	},
	99
);
add_filter(
	'jetpack_seo_meta_tags',
	function ( $tags ) {
		$desc = is_singular( 'page' ) ? mc_members_description() : null;
		if ( null !== $desc ) {
			$tags['description'] = $desc;
		}
		return $tags;
	},
	99
);

/**
 * On a page with a document library, the File blocks it is built from (kept in a group with the
 * class "mc-doc-files") are not shown as well: the library lists them instead.
 */
add_filter(
	'render_block_core/group',
	function ( $html, $block ) {
		$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
		if ( ! is_admin() && preg_match( '/(^|\s)mc-doc-files(\s|$)/', $class ) ) {
			return '';
		}
		return $html;
	},
	10,
	2
);
