<?php
/**
 * Richmond Park paths: asset registration.
 *
 * Adapted from the handoff loader. Instead of enqueuing on is_front_page(),
 * the assets are registered here and attached to the matthias-court/paths
 * block, so they load exactly where the component renders.
 *
 * @package matthias-court
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mc_richmond_paths_register_assets() {
	$base = '/assets/richmond-paths/';
	wp_register_style(
		'mc-richmond-paths',
		get_theme_file_uri( $base . 'animation.css' ),
		array(),
		(string) filemtime( get_theme_file_path( $base . 'animation.css' ) )
	);
	wp_register_script(
		'mc-richmond-paths',
		get_theme_file_uri( $base . 'animation.js' ),
		array(),
		(string) filemtime( get_theme_file_path( $base . 'animation.js' ) ),
		array( 'in_footer' => true )
	);
}
add_action( 'init', 'mc_richmond_paths_register_assets', 5 );
